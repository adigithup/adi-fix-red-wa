import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { format } from "date-fns";
import { 
  LayoutDashboard, Server, Users, Settings, Plus, RefreshCw, Trash2, 
  AlertTriangle, CheckCircle2, XCircle, Mail, KeyRound, ShieldAlert 
} from "lucide-react";

import { 
  useGetSenders, useAddSender, useDeleteSender, useResetSenders, 
  useGetUsers, getGetSendersQueryKey, getGetStatsQueryKey 
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Progress } from "@/components/ui/progress";

const senderFormSchema = z.object({
  email: z.string().email("Invalid email address"),
  pass: z.string().min(1, "App password is required"),
  limit: z.coerce.number().min(1, "Limit must be at least 1"),
});

export default function Admin() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddSenderOpen, setIsAddSenderOpen] = useState(false);

  const { data: senders, isLoading: sendersLoading } = useGetSenders();
  const { data: users, isLoading: usersLoading } = useGetUsers();

  const addSender = useAddSender();
  const deleteSender = useDeleteSender();
  const resetSenders = useResetSenders();

  const form = useForm<z.infer<typeof senderFormSchema>>({
    resolver: zodResolver(senderFormSchema),
    defaultValues: {
      email: "",
      pass: "",
      limit: 100,
    },
  });

  function onAddSender(values: z.infer<typeof senderFormSchema>) {
    addSender.mutate({ data: values }, {
      onSuccess: () => {
        toast({ title: "Sender added successfully" });
        setIsAddSenderOpen(false);
        form.reset();
        queryClient.invalidateQueries({ queryKey: getGetSendersQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetStatsQueryKey() });
      },
      onError: (error: any) => {
        toast({
          title: "Failed to add sender",
          description: error.response?.data?.error || "Unknown error",
          variant: "destructive"
        });
      }
    });
  }

  function onDeleteSender(id: number) {
    deleteSender.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Sender deleted" });
        queryClient.invalidateQueries({ queryKey: getGetSendersQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetStatsQueryKey() });
      },
      onError: (error: any) => {
        toast({
          title: "Failed to delete sender",
          description: error.response?.data?.error || "Unknown error",
          variant: "destructive"
        });
      }
    });
  }

  function onResetSenders() {
    resetSenders.mutate(undefined, {
      onSuccess: () => {
        toast({ title: "All senders reset and re-enabled" });
        queryClient.invalidateQueries({ queryKey: getGetSendersQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetStatsQueryKey() });
      },
      onError: (error: any) => {
        toast({
          title: "Failed to reset senders",
          description: error.response?.data?.error || "Unknown error",
          variant: "destructive"
        });
      }
    });
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Settings className="w-8 h-8 text-primary" />
            Admin Control Panel
          </h1>
          <p className="text-muted-foreground mt-1">Manage the community's resources. Open to everyone.</p>
        </div>
        
        <AlertTriangle className="w-10 h-10 text-yellow-500 opacity-20 hidden md:block" />
      </div>

      <Tabs defaultValue="senders" className="space-y-6">
        <TabsList className="bg-muted/50 p-1">
          <TabsTrigger value="senders" className="flex gap-2"><Server className="w-4 h-4" /> Senders Pool</TabsTrigger>
          <TabsTrigger value="users" className="flex gap-2"><Users className="w-4 h-4" /> Users List</TabsTrigger>
        </TabsList>

        <TabsContent value="senders" className="space-y-6 m-0">
          <div className="flex justify-between items-center bg-card p-4 rounded-lg border border-border shadow-sm">
            <div>
              <h3 className="font-bold text-lg">Email Senders Pool</h3>
              <p className="text-sm text-muted-foreground">Emails used to dispatch appeals to WhatsApp</p>
            </div>
            <div className="flex gap-3">
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" className="border-primary/20 hover:bg-primary/5 text-primary">
                    <RefreshCw className="w-4 h-4 mr-2" /> Reset All
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Reset all sender limits?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This will reset the used count to 0 for all senders and re-enable any disabled senders. Use this when you are sure the limits have reset on the email provider side.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={onResetSenders} className="bg-primary text-primary-foreground hover:bg-primary/90">
                      Yes, reset all
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>

              <Dialog open={isAddSenderOpen} onOpenChange={setIsAddSenderOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 mr-2" /> Add Sender
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add New Sender</DialogTitle>
                    <DialogDescription>Add an email account to the community pool. Needs to be an App Password.</DialogDescription>
                  </DialogHeader>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onAddSender)} className="space-y-4 pt-4">
                      <FormField control={form.control} name="email" render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Address</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Mail className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                              <Input placeholder="bot@example.com" className="pl-9" {...field} />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )} />
                      <FormField control={form.control} name="pass" render={({ field }) => (
                        <FormItem>
                          <FormLabel>App Password</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <KeyRound className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                              <Input type="password" placeholder="••••••••••••" className="pl-9" {...field} />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )} />
                      <FormField control={form.control} name="limit" render={({ field }) => (
                        <FormItem>
                          <FormLabel>Daily Limit</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )} />
                      <div className="pt-4 flex justify-end">
                        <Button type="submit" disabled={addSender.isPending}>
                          {addSender.isPending ? "Adding..." : "Add Sender"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <Card>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead>Email</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Usage</TableHead>
                    <TableHead>Failures</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sendersLoading ? (
                    <TableRow>
                      <TableCell colSpan={5} className="h-24 text-center text-muted-foreground">
                        Loading senders...
                      </TableCell>
                    </TableRow>
                  ) : senders?.length ? (
                    senders.map((sender) => {
                      const usagePercent = Math.round((sender.used / sender.limit) * 100);
                      return (
                        <TableRow key={sender.id}>
                          <TableCell className="font-medium">{sender.email}</TableCell>
                          <TableCell>
                            {sender.disabled ? (
                              <Badge variant="destructive" className="flex w-max items-center gap-1">
                                <XCircle className="w-3 h-3" /> Disabled
                              </Badge>
                            ) : (
                              <Badge variant="default" className="bg-green-500 hover:bg-green-600 flex w-max items-center gap-1">
                                <CheckCircle2 className="w-3 h-3" /> Active
                              </Badge>
                            )}
                            {sender.disabledReason && (
                              <div className="text-xs text-muted-foreground mt-1 max-w-[200px] truncate" title={sender.disabledReason}>
                                {sender.disabledReason}
                              </div>
                            )}
                          </TableCell>
                          <TableCell className="w-[200px]">
                            <div className="flex justify-between text-xs mb-1">
                              <span>{sender.used} / {sender.limit}</span>
                              <span className={usagePercent > 90 ? "text-destructive font-bold" : ""}>{usagePercent}%</span>
                            </div>
                            <Progress value={usagePercent} className="h-2" />
                          </TableCell>
                          <TableCell>
                            {sender.failCount! > 0 ? (
                              <span className="text-destructive font-bold">{sender.failCount}</span>
                            ) : (
                              <span className="text-muted-foreground">0</span>
                            )}
                          </TableCell>
                          <TableCell className="text-right">
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive hover:bg-destructive/10">
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Delete sender?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Are you sure you want to remove {sender.email} from the pool? This cannot be undone.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => onDeleteSender(sender.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                                    Delete
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </TableCell>
                        </TableRow>
                      );
                    })
                  ) : (
                    <TableRow>
                      <TableCell colSpan={5} className="h-32 text-center">
                        <div className="flex flex-col items-center justify-center text-muted-foreground">
                          <ShieldAlert className="w-8 h-8 mb-2 opacity-20" />
                          <p>No senders configured.</p>
                          <p className="text-sm">The tool cannot function without email senders.</p>
                        </div>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="users" className="m-0">
          <Card>
            <CardHeader>
              <CardTitle>Registered Users</CardTitle>
              <CardDescription>Users who have interacted with the tool.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User ID</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Total Fixes</TableHead>
                      <TableHead>Success Rate</TableHead>
                      <TableHead>Joined</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {usersLoading ? (
                      <TableRow>
                        <TableCell colSpan={5} className="h-24 text-center text-muted-foreground">
                          Loading users...
                        </TableCell>
                      </TableRow>
                    ) : users?.length ? (
                      users.map((user) => {
                        const successRate = user.totalFix > 0 
                          ? Math.round((user.totalSuccess / user.totalFix) * 100) 
                          : 0;
                        
                        return (
                          <TableRow key={user.id}>
                            <TableCell className="font-mono text-xs">{user.id}</TableCell>
                            <TableCell className="font-medium">
                              {user.name}
                              {user.username && <span className="text-muted-foreground ml-2">@{user.username}</span>}
                            </TableCell>
                            <TableCell>{user.totalFix}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <span className={successRate > 0 ? "text-green-500 font-medium" : ""}>
                                  {user.totalSuccess}
                                </span>
                                <span className="text-xs text-muted-foreground">({successRate}%)</span>
                              </div>
                            </TableCell>
                            <TableCell className="text-muted-foreground text-sm">
                              {user.joinedAt ? format(new Date(user.joinedAt), "MMM d, yyyy") : "N/A"}
                            </TableCell>
                          </TableRow>
                        );
                      })
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} className="h-32 text-center text-muted-foreground">
                          No users found.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
