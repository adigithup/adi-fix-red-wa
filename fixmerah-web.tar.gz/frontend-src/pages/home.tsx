import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { formatDistanceToNow } from "date-fns";
import { Activity, AlertCircle, CheckCircle2, XCircle, Users, BarChart3, Clock, Loader2 } from "lucide-react";
import { useGetStats, useGetHistory, useSubmitFix, getGetHistoryQueryKey, getGetStatsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";

const formSchema = z.object({
  phone: z.string().min(8, "Phone number must be at least 8 digits").max(15, "Phone number is too long").regex(/^[0-9+]+$/, "Only numbers and + allowed"),
});

export default function Home() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [successResult, setSuccessResult] = useState<{ appealId: string; message: string } | null>(null);

  const { data: stats, isLoading: statsLoading } = useGetStats({
    query: {
      refetchInterval: 10000,
    }
  });

  const { data: history, isLoading: historyLoading } = useGetHistory({ limit: 10 }, {
    query: {
      refetchInterval: 10000,
    }
  });

  const submitFix = useSubmitFix();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      phone: "",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    setSuccessResult(null);
    submitFix.mutate({ data: { phone: values.phone } }, {
      onSuccess: (data) => {
        if (data.success) {
          setSuccessResult({
            appealId: data.appealId,
            message: data.message,
          });
          form.reset();
          queryClient.invalidateQueries({ queryKey: getGetHistoryQueryKey({ limit: 10 }) });
          queryClient.invalidateQueries({ queryKey: getGetStatsQueryKey() });
          toast({
            title: "Success",
            description: "Appeal submitted successfully.",
          });
        } else {
          toast({
            title: "Failed",
            description: data.message || "Failed to submit appeal.",
            variant: "destructive",
          });
        }
      },
      onError: (error: any) => {
        toast({
          title: "Error",
          description: error.response?.data?.error || error.message || "An unexpected error occurred.",
          variant: "destructive",
        });
      }
    });
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* Hero Section */}
      <section className="text-center space-y-4 py-8">
        <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight text-foreground">
          Fix Your WhatsApp <span className="text-primary">Instantly</span>
        </h1>
        <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
          The free, unlimited community tool to recover banned WhatsApp numbers. No payments, no limits, just results.
        </p>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        
        {/* Main Action Area */}
        <div className="md:col-span-2 space-y-6">
          <Card className="border-primary/20 shadow-lg shadow-primary/5">
            <CardHeader className="bg-primary/5 border-b border-border/40 pb-4">
              <CardTitle className="text-2xl flex items-center gap-2">
                <Activity className="w-6 h-6 text-primary" />
                Submit Number
              </CardTitle>
              <CardDescription>Enter the banned phone number including country code (e.g. +62812...)</CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-base">Phone Number</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="+628..." 
                            className="text-lg h-12" 
                            disabled={submitFix.isPending}
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button 
                    type="submit" 
                    size="lg" 
                    className="w-full text-lg h-12 font-semibold"
                    disabled={submitFix.isPending}
                  >
                    {submitFix.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      "Fix Number Now"
                    )}
                  </Button>
                </form>
              </Form>

              {successResult && (
                <Alert className="mt-6 border-green-500/50 bg-green-500/10 text-green-700 dark:text-green-400">
                  <CheckCircle2 className="h-5 w-5 !text-green-600 dark:!text-green-400" />
                  <AlertTitle className="text-lg font-bold">Appeal Submitted!</AlertTitle>
                  <AlertDescription className="mt-2 space-y-2">
                    <p>{successResult.message}</p>
                    <div className="bg-background/50 rounded p-3 text-sm font-mono break-all border border-green-500/20">
                      Appeal ID: {successResult.appealId}
                    </div>
                    <p className="text-sm opacity-90">Please wait 1-2 minutes for the notification from WhatsApp.</p>
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>

          {/* History Feed */}
          <div className="space-y-4">
            <h3 className="text-xl font-bold flex items-center gap-2">
              <Clock className="w-5 h-5 text-muted-foreground" />
              Recent Activity
            </h3>
            
            {historyLoading ? (
              <div className="space-y-3">
                {[1,2,3].map(i => (
                  <div key={i} className="h-16 bg-muted animate-pulse rounded-lg border border-border"></div>
                ))}
              </div>
            ) : history?.length ? (
              <div className="space-y-3">
                {history.map((entry) => (
                  <div key={entry.id} className="flex items-center justify-between p-4 bg-card rounded-lg border border-border shadow-sm transition-all hover:border-primary/30">
                    <div className="flex items-center gap-3">
                      {entry.status === 'success' ? (
                        <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center">
                          <CheckCircle2 className="w-5 h-5 text-green-500" />
                        </div>
                      ) : (
                        <div className="w-10 h-10 rounded-full bg-red-500/10 flex items-center justify-center">
                          <XCircle className="w-5 h-5 text-red-500" />
                        </div>
                      )}
                      <div>
                        <div className="font-mono font-medium text-lg tracking-tight">{entry.phone}</div>
                        <div className="text-xs text-muted-foreground flex items-center gap-2">
                          <span>{formatDistanceToNow(new Date(entry.createdAt), { addSuffix: true })}</span>
                          {entry.appealId && (
                            <>
                              <span>&bull;</span>
                              <span className="font-mono opacity-70">ID: {entry.appealId.slice(0, 8)}...</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                    <Badge variant={entry.status === 'success' ? 'default' : 'destructive'} className={entry.status === 'success' ? 'bg-green-500 hover:bg-green-600' : ''}>
                      {entry.status}
                    </Badge>
                  </div>
                ))}
              </div>
            ) : (
              <Card className="bg-muted/50 border-dashed">
                <CardContent className="py-8 text-center text-muted-foreground">
                  No recent activity found. Be the first to use the tool!
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Sidebar Stats */}
        <div className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-primary" />
                Live Network Stats
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {statsLoading ? (
                <div className="space-y-4">
                  {[1,2,3,4].map(i => (
                    <div key={i} className="h-12 bg-muted animate-pulse rounded"></div>
                  ))}
                </div>
              ) : stats ? (
                <>
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">Total Fixes Attempted</div>
                    <div className="text-3xl font-bold">{stats.totalFix.toLocaleString()}</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">Total Successful Fixes</div>
                    <div className="text-3xl font-bold text-green-500">{stats.totalSuccess.toLocaleString()}</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">Success Rate</div>
                    <div className="text-2xl font-bold">{stats.percentage}</div>
                  </div>
                  <div className="pt-4 border-t border-border/50 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium flex items-center gap-2">
                        <Activity className="w-4 h-4 text-primary" />
                        Active Senders
                      </div>
                      <Badge variant="secondary">{stats.activeSenders} / {stats.totalSenders}</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium flex items-center gap-2">
                        <Users className="w-4 h-4 text-primary" />
                        Total Users
                      </div>
                      <span className="font-bold">{stats.totalUsers.toLocaleString()}</span>
                    </div>
                  </div>
                </>
              ) : (
                <div className="text-sm text-muted-foreground">Failed to load stats.</div>
              )}
            </CardContent>
          </Card>

          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Community Notice</AlertTitle>
            <AlertDescription className="text-sm text-muted-foreground mt-1">
              This tool relies on a pool of sender emails provided by the community. If fixes fail, the pool might be temporarily exhausted.
            </AlertDescription>
          </Alert>
        </div>
      </div>
    </div>
  );
}
