import { Trophy, Medal, Award, User, Loader2 } from "lucide-react";
import { useGetLeaderboard } from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function Leaderboard() {
  const { data: leaderboard, isLoading } = useGetLeaderboard();

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="text-center space-y-4 mb-10">
        <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
          <Trophy className="w-8 h-8 text-primary" />
        </div>
        <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight">Top Contributors</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          The most active users helping the community. Names are masked to protect privacy.
        </p>
      </div>

      <Card className="border-primary/10 shadow-lg">
        <CardHeader className="bg-muted/30 border-b border-border/40">
          <CardTitle>Leaderboard</CardTitle>
          <CardDescription>Ranked by total successful fixes</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
              <Loader2 className="w-8 h-8 animate-spin mb-4" />
              <p>Loading rankings...</p>
            </div>
          ) : leaderboard && leaderboard.length > 0 ? (
            <div className="divide-y divide-border/50">
              {leaderboard.map((entry) => (
                <div key={entry.rank} className="flex items-center p-4 sm:px-6 hover:bg-muted/30 transition-colors">
                  <div className="w-12 sm:w-16 flex justify-center">
                    {entry.rank === 1 ? (
                      <Trophy className="w-8 h-8 text-yellow-500 drop-shadow-sm" />
                    ) : entry.rank === 2 ? (
                      <Medal className="w-7 h-7 text-gray-400 drop-shadow-sm" />
                    ) : entry.rank === 3 ? (
                      <Medal className="w-6 h-6 text-amber-700 drop-shadow-sm" />
                    ) : (
                      <span className="text-lg font-bold text-muted-foreground w-8 text-center">{entry.rank}</span>
                    )}
                  </div>
                  
                  <div className="flex-1 flex items-center gap-4 ml-4">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <User className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <div className="font-bold text-lg">{entry.name}</div>
                      <div className="text-sm text-muted-foreground">Community Member</div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-2xl font-black text-primary">{entry.count}</div>
                    <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Fixes</div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-20 text-center text-muted-foreground">
              <Award className="w-12 h-12 mx-auto mb-4 opacity-20" />
              <p>No data available yet.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
