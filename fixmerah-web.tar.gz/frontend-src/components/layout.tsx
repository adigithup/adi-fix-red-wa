import { Link, useLocation } from "wouter";
import { Activity, LayoutDashboard, Trophy } from "lucide-react";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <div className="min-h-[100dvh] flex flex-col bg-background">
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded flex items-center justify-center">
              <Activity className="w-5 h-5 text-primary-foreground" />
            </div>
            <Link href="/" className="font-bold text-lg tracking-tight hover:text-primary transition-colors">
              Fix Merah
            </Link>
          </div>
          <nav className="flex items-center gap-1 sm:gap-2">
            <Link 
              href="/" 
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                location === "/" 
                  ? "bg-primary/10 text-primary" 
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              }`}
            >
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4" />
                <span className="hidden sm:inline">Fix</span>
              </div>
            </Link>
            <Link 
              href="/leaderboard" 
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                location === "/leaderboard" 
                  ? "bg-primary/10 text-primary" 
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              }`}
            >
              <div className="flex items-center gap-2">
                <Trophy className="w-4 h-4" />
                <span className="hidden sm:inline">Leaderboard</span>
              </div>
            </Link>
            <Link 
              href="/admin" 
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                location === "/admin" 
                  ? "bg-primary/10 text-primary" 
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              }`}
            >
              <div className="flex items-center gap-2">
                <LayoutDashboard className="w-4 h-4" />
                <span className="hidden sm:inline">Admin</span>
              </div>
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex-1 flex flex-col">
        {children}
      </main>
      <footer className="border-t border-border/40 py-6 md:py-0">
        <div className="container mx-auto px-4 flex flex-col md:flex-row items-center justify-center md:h-16 gap-4">
          <p className="text-sm text-muted-foreground">
            Built for the community. Free forever. No limits.
          </p>
        </div>
      </footer>
    </div>
  );
}
