/*
 * 🤖 WHATSAPP BOT ULTRA V9 - CONFIGURATION
 * 📦 Version: 9.0.0 | Full Features Edition
 */

const config = {
  // ════════════════════════════════════════════════════════
  // 📱 BOT BASIC CONFIG
  // ════════════════════════════════════════════════════════
  
  phoneNumber: '6285124002198', // Ganti dengan nomor WhatsApp mu
  usePairingCode: true, // true = Pairing Code | false = QR Code
  sessionName: 'session_ultra_v9',
  
  // Bot Info
  botName: '🚀 WHATSAPP BOT ULTRA V9',
  botVersion: '9.0.0',
  ownerNumber: ['6285124002198@s.whatsapp.net'], // Array of owner numbers
  ownerName: 'Ultra Dev',
  
  // Prefix & Mode
  prefix: ['.', '!', '#', '/'],
  mode: 'public', // public | self
  
  // Auto Features
  autoRead: true,
  autoTyping: true,
  autoReact: true,
  antiCall: true,
  antiDelete: true,
  antiLink: false,
  antiToxic: true,
  welcomeMsg: true,

  // ════════════════════════════════════════════════════════
  // 🤖 AI CONFIGURATION
  // ════════════════════════════════════════════════════════
  
  groqApiKey: '', // Isi API Key Groq dari https://console.groq.com/
  aiModel: 'llama-3.1-8b-instant', // Model AI (cek: https://console.groq.com/docs/models)
  aiSystemPrompt: `Kamu adalah asisten AI yang cerdas, ramah, dan membantu bernama "BOT ULTRA". 
Kamu tertanam di dalam bot WhatsApp dengan fitur lengkap.
Jawablah pertanyaan user dengan sopan, jelas, dan menggunakan Bahasa Indonesia.
Gunakan emoji yang sesuai untuk membuat percakapan lebih menarik.
Jika tidak tahu jawabannya, katakan "Maaf, saya tidak tahu tentang itu."
Kamu bisa membantu dalam berbagai hal: coding, sekolah, pekerjaan, hiburan, dll.`,

  // Alternative AI APIs (Optional)
  openaiApiKey: '',
  geminiApiKey: '',
  claudeApiKey: '',

  // Context Files
  contextFolderPath: './context',
  useContext: false, // Enable/disable PDF/TXT context

  // ════════════════════════════════════════════════════════
  // 💳 PAYMENT / STORE CONFIG
  // ════════════════════════════════════════════════════════
  
  payment: {
    dana: '6285124002198',
    ovo: '6285124002198',
    gopay: '6285124002198',
    paypal: 'paypal@example.com',
    qris: './assets/qris.png'
  },

  // Store Products
  products: [
    { id: 1, name: '👑 Premium Bot 1 Bulan', price: 15000, desc: 'Akses full fitur premium' },
    { id: 2, name: '📦 Script Bot Full Fitur', price: 50000, desc: 'Source code lengkap' },
    { id: 3, name: '🔧 Jasa Install Bot', price: 25000, desc: 'Install & setup bot' },
    { id: 4, name: '🎨 Custom Sticker Pack', price: 10000, desc: 'Buat sticker custom' },
    { id: 5, name: '🌟 Premium Permanen', price: 25000, desc: 'Premium selamanya' }
  ],

  // ════════════════════════════════════════════════════════
  // 🎮 RPG / GAME CONFIG
  // ════════════════════════════════════════════════════════
  
  rpg: {
    maxLevel: 100,
    expPerMessage: 10,
    coinReward: { min: 5, max: 50 },
    dailyReward: { coins: 100, exp: 50 },
    weeklyReward: { coins: 500, exp: 200 },
    monthlyReward: { coins: 2000, exp: 1000 }
  },

  // ════════════════════════════════════════════════════════
  // 🛡️ SECURITY CONFIG
  // ════════════════════════════════════════════════════════
  
  security: {
    antibug: true,
    anticall: true,
    antivirtex: true,
    antispam: true,
    maxCommandPerMinute: 30,
    cooldownTime: 3000, // ms
    allowedCountries: ['62'], // Country codes allowed
    blockForeign: false
  },

  // ════════════════════════════════════════════════════════
  // 🎨 STYLE & MESSAGES
  // ════════════════════════════════════════════════════════
  
  style: {
    header: '╔══════════════════════════════════════╗\n🚀 WHATSAPP BOT ULTRA V9 🚀\n╚══════════════════════════════════════╝',
    footer: '\n━━━━━━━━━━━━━━━━━━━━\n⚡ Powered by Baileys MD\n📱 Version 9.0.0\n👨‍💻 Creator: Ultra Dev',
    
    // Welcome Message Template
    welcomeMessage: `
👋 *SELAMAT DATANG DI {groupname}!*

👤 User: @{user}
📅 Join: {date}

Silakan baca deskripsi grup ya~ 😊
`.trim(),

    // Goodbye Message Template
    goodbyeMessage: `
👋 *GOODBYE!*

@{user} meninggalkan grup 👋
Semoga sukses selalu!
`.trim()
  },

  // ════════════════════════════════════════════════════════
  // 🔗 API KEYS (External Services)
  // ════════════════════════════════════════════════════════
  
  apis: {
    // Weather API (OpenWeatherMap)
    weatherApiKey: '',
    
    // Screenshot API
    screenshotApi: 'https://image.thum.io/get/fullpage/',
    
    // URL Shortener
    tinyurlApi: 'https://tinyurl.com/api-create.php?url=',
    
    // OCR Space (optional)
    ocrApiKey: ''
  },

  // ════════════════════════════════════════════════════════
  // 🎯 BOT DESTINATION
  // ════════════════════════════════════════════════════════
  
  botDestination: 'both', // 'group' | 'private' | 'both'

};

export default config;