# Fix Merah Web

A free, unlimited web tool for recovering banned/red-listed WhatsApp numbers. No payment, no daily limits — everyone gets full access.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/fixmerah-web run dev` — run the frontend (port 18204)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite + Tailwind CSS + shadcn/ui
- API: Express 5 + nodemailer
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — API contract (source of truth)
- `lib/db/src/schema/` — DB schema (senders, history, users)
- `artifacts/api-server/src/routes/` — API route handlers (fix, senders, stats, users)
- `artifacts/fixmerah-web/src/` — React frontend
- `artifacts/fixmerah-web/src/pages/` — Home, Leaderboard, Admin pages

## Architecture decisions

- Open admin panel — no login required, anyone can manage senders
- Smart sender rotation — picks the best sender by usage ratio and fail count
- Rate limiting per IP (10 req/min) via in-memory map, cleaned every 5 min
- Phone numbers are masked in history and leaderboard for privacy
- Nodemailer sends email to `support@support.whatsapp.com` via gmail SMTP

## Product

- **Home** (`/`) — Submit a phone number, view live stats and recent fix activity
- **Leaderboard** (`/leaderboard`) — Top 10 most active users (masked)
- **Admin** (`/admin`) — Manage senders, view users and full stats; open to everyone

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Senders use Gmail App Passwords (not regular passwords)
- Run `pnpm --filter @workspace/db run push` after any schema changes
- Always re-run codegen after changing `openapi.yaml`

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
