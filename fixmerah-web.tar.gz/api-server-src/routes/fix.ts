import { Router, type IRouter } from "express";
import { db, historyTable, sendersTable, usersTable } from "@workspace/db";
import { desc, eq, sql, and, gt } from "drizzle-orm";
import {
  SubmitFixBody,
  GetHistoryQueryParams,
} from "@workspace/api-zod";
import nodemailer from "nodemailer";

const router: IRouter = Router();

function normalizePhone(n: string): string {
  const digits = n.replace(/\D/g, "");
  return "+" + digits;
}

function maskPhone(phone: string): string {
  if (!phone || phone.length < 9) return phone;
  return phone.slice(0, 5) + "****" + phone.slice(-4);
}

function genAppealId(): string {
  return "LRFM" + Math.random().toString(36).toUpperCase().slice(2, 8) + Date.now().toString(16).toUpperCase();
}

function validPhone(n: string): boolean {
  return /^\+?[0-9]{8,15}$/.test(n);
}

const rateLimits = new Map<string, number[]>();

function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const requests = rateLimits.get(ip) || [];
  const recent = requests.filter(t => now - t < 60000);
  if (recent.length >= 10) return false;
  recent.push(now);
  rateLimits.set(ip, recent);
  return true;
}

setInterval(() => {
  const now = Date.now();
  for (const [ip, timestamps] of rateLimits.entries()) {
    const filtered = timestamps.filter(t => now - t < 60000);
    if (filtered.length === 0) rateLimits.delete(ip);
    else rateLimits.set(ip, filtered);
  }
}, 300000);

router.post("/fix", async (req, res): Promise<void> => {
  const ip = (req.headers["x-forwarded-for"] as string)?.split(",")[0] || req.ip || "unknown";

  if (!checkRateLimit(ip)) {
    res.status(429).json({ error: "Terlalu banyak permintaan. Coba lagi dalam 1 menit." });
    return;
  }

  const parsed = SubmitFixBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Data tidak valid" });
    return;
  }

  const { phone } = parsed.data;

  if (!validPhone(phone)) {
    res.status(400).json({ error: "Format nomor tidak valid. Contoh: 6281234567890" });
    return;
  }

  const normalizedPhone = normalizePhone(phone);
  const appealId = genAppealId();

  const activeSenders = await db
    .select()
    .from(sendersTable)
    .where(and(eq(sendersTable.disabled, false), gt(sql`${sendersTable.limit} - ${sendersTable.used}`, 0)));

  if (activeSenders.length === 0) {
    await db.insert(historyTable).values({
      phone: normalizedPhone,
      status: "fail",
      appealId,
      sender: null,
      createdAt: Date.now(),
    });
    res.status(200).json({
      success: false,
      appealId,
      phone: normalizedPhone,
      message: "Semua sender sedang sibuk. Coba lagi beberapa saat.",
      sender: null,
    });
    return;
  }

  const scored = activeSenders.map(s => ({
    sender: s,
    score: (1 - (s.used / (s.limit || 50))) - (s.failCount * 0.1),
  })).sort((a, b) => b.score - a.score);

  const best = scored[0].sender;

  try {
    const transport = nodemailer.createTransport({
      service: "gmail",
      auth: { user: best.email, pass: best.pass },
      connectionTimeout: 15000,
      greetingTimeout: 10000,
      socketTimeout: 20000,
    } as any);

    await transport.sendMail({
      from: best.email,
      to: "support@support.whatsapp.com",
      subject: `Request ${normalizedPhone}`,
      text: `Hello, request ${normalizedPhone}`,
    });

    transport.close();

    await db.update(sendersTable)
      .set({ used: sql`${sendersTable.used} + 1` })
      .where(eq(sendersTable.id, best.id));

    await db.insert(historyTable).values({
      phone: normalizedPhone,
      status: "success",
      appealId,
      sender: best.email,
      createdAt: Date.now(),
    });

    req.log.info({ phone: normalizedPhone, sender: best.email, appealId }, "Fix merah success");

    res.json({
      success: true,
      appealId,
      phone: normalizedPhone,
      message: "Berhasil dikirim! Notifikasi update akan datang dalam 1-2 menit.",
      sender: best.email,
    });

  } catch (err: any) {
    req.log.error({ err: err.message, sender: best.email }, "Fix merah failed");

    const errCode = err.code as string | undefined;
    if (errCode && ["EAUTH", "ECONNECTION", "ETIMEDOUT", "ESOCKET"].includes(errCode)) {
      await db.update(sendersTable)
        .set({ disabled: true, disabledReason: err.message, failCount: sql`${sendersTable.failCount} + 1` })
        .where(eq(sendersTable.id, best.id));
    } else {
      await db.update(sendersTable)
        .set({ failCount: sql`${sendersTable.failCount} + 1` })
        .where(eq(sendersTable.id, best.id));
    }

    await db.insert(historyTable).values({
      phone: normalizedPhone,
      status: "fail",
      appealId,
      sender: best.email,
      createdAt: Date.now(),
    });

    res.json({
      success: false,
      appealId,
      phone: normalizedPhone,
      message: "Gagal mengirim. Silakan coba lagi.",
      sender: best.email,
    });
  }
});

router.get("/fix/history", async (req, res): Promise<void> => {
  const params = GetHistoryQueryParams.safeParse(req.query);
  const limit = params.success ? (params.data.limit ?? 20) : 20;

  const rows = await db
    .select()
    .from(historyTable)
    .orderBy(desc(historyTable.createdAt))
    .limit(limit);

  const masked = rows.map(h => ({
    id: h.id,
    phone: maskPhone(h.phone),
    status: h.status,
    appealId: h.appealId,
    sender: h.sender ? h.sender.slice(0, 5) + "****" : null,
    createdAt: new Date(h.createdAt).toISOString(),
  }));

  res.json(masked);
});

export default router;
