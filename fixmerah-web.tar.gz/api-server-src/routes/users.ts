import { Router, type IRouter } from "express";
import { db, usersTable, historyTable } from "@workspace/db";
import { sql, count } from "drizzle-orm";

const router: IRouter = Router();

router.get("/users", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      id: usersTable.id,
      name: usersTable.name,
      username: usersTable.username,
      joinedAt: usersTable.joinedAt,
      totalFix: sql<number>`count(${historyTable.id})::int`,
      totalSuccess: sql<number>`count(${historyTable.id}) filter (where ${historyTable.status} = 'success')::int`,
    })
    .from(usersTable)
    .leftJoin(historyTable, sql`${historyTable.phone} like '%'`)
    .groupBy(usersTable.id)
    .orderBy(sql`count(${historyTable.id}) desc`)
    .limit(50);

  res.json(rows.map(u => ({
    id: u.id,
    name: u.name,
    username: u.username ?? null,
    totalFix: Number(u.totalFix),
    totalSuccess: Number(u.totalSuccess),
    joinedAt: u.joinedAt ? new Date(u.joinedAt).toISOString() : new Date().toISOString(),
  })));
});

export default router;
