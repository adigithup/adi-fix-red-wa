import { Router, type IRouter } from "express";
import healthRouter from "./health";
import fixRouter from "./fix";
import sendersRouter from "./senders";
import statsRouter from "./stats";
import usersRouter from "./users";

const router: IRouter = Router();

router.use(healthRouter);
router.use(fixRouter);
router.use(sendersRouter);
router.use(statsRouter);
router.use(usersRouter);

export default router;
