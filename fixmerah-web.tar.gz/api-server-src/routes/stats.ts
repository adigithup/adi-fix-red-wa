import { Router, type IRouter } from "express";
import { db, sendersTable, historyTable, usersTable } from "@workspace/db";
import { eq, sql, count } from "drizzle-orm";

const router: IRouter = Router();

router.get("/stats", async (_req, res): Promise<void> => {
  const [sendersStats] = await db
    .select({
      total: count(),
      active: sql<number>`count(*) filter (where not disabled)`,
    })
    .from(sendersTable);

  const [usersCount] = await db.select({ total: count() }).from(usersTable);

  const [historyStats] = await db
    .select({
      total: count(),
      success: sql<number>`count(*) filter (where status = 'success')`,
    })
    .from(historyTable);

  const totalFix = Number(historyStats.total);
  const totalSuccess = Number(historyStats.success);
  const percentage = totalFix > 0 ? ((totalSuccess / totalFix) * 100).toFixed(1) : "0.0";

  res.json({
    totalSenders: Number(sendersStats.total),
    activeSenders: Number(sendersStats.active),
    totalUsers: Number(usersCount.total),
    totalFix,
    totalSuccess,
    percentage,
    queueLength: 0,
  });
});

router.get("/stats/leaderboard", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      phone: historyTable.phone,
      count: sql<number>`count(*)::int`,
    })
    .from(historyTable)
    .groupBy(historyTable.phone)
    .orderBy(sql`count(*) desc`)
    .limit(10);

  const leaderboard = rows.map((row, i) => ({
    rank: i + 1,
    name: row.phone.slice(0, 3) + "****" + row.phone.slice(-3),
    count: Number(row.count),
  }));

  res.json(leaderboard);
});

export default router;
