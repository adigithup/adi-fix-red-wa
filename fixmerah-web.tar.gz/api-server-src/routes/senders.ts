import { Router, type IRouter } from "express";
import { db, sendersTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { AddSenderBody, DeleteSenderParams } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/senders", async (_req, res): Promise<void> => {
  const rows = await db.select().from(sendersTable).orderBy(sendersTable.id);
  res.json(rows.map(s => ({
    id: s.id,
    email: s.email,
    limit: s.limit,
    used: s.used,
    disabled: s.disabled,
    disabledReason: s.disabledReason ?? null,
    failCount: s.failCount,
  })));
});

router.post("/senders", async (req, res): Promise<void> => {
  const parsed = AddSenderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Data sender tidak valid" });
    return;
  }

  const { email, pass, limit } = parsed.data;

  if (!email.includes("@")) {
    res.status(400).json({ error: "Format email tidak valid" });
    return;
  }

  const [sender] = await db.insert(sendersTable).values({
    email: email.trim(),
    pass: pass.trim(),
    limit,
    used: 0,
    disabled: false,
    failCount: 0,
    addedAt: Date.now(),
    lastReset: Date.now(),
  }).returning();

  res.status(201).json({
    id: sender.id,
    email: sender.email,
    limit: sender.limit,
    used: sender.used,
    disabled: sender.disabled,
    disabledReason: sender.disabledReason ?? null,
    failCount: sender.failCount,
  });
});

router.post("/senders/reset", async (_req, res): Promise<void> => {
  await db.update(sendersTable).set({
    used: 0,
    disabled: false,
    disabledReason: null,
    failCount: 0,
    lastReset: Date.now(),
  });

  res.json({ success: true, message: "Semua sender berhasil direset" });
});

router.delete("/senders/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = DeleteSenderParams.safeParse({ id: parseInt(raw, 10) });

  if (!params.success) {
    res.status(400).json({ error: "ID tidak valid" });
    return;
  }

  const [deleted] = await db.delete(sendersTable)
    .where(eq(sendersTable.id, params.data.id))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: "Sender tidak ditemukan" });
    return;
  }

  res.json({ success: true, message: `Sender ${deleted.email} berhasil dihapus` });
});

export default router;
