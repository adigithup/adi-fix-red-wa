import { pgTable, serial, text, integer, boolean, bigint } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const sendersTable = pgTable("senders", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  pass: text("pass").notNull(),
  limit: integer("limit").notNull().default(50),
  used: integer("used").notNull().default(0),
  disabled: boolean("disabled").notNull().default(false),
  disabledReason: text("disabled_reason"),
  failCount: integer("fail_count").notNull().default(0),
  lastReset: bigint("last_reset", { mode: "number" }),
  addedAt: bigint("added_at", { mode: "number" }).notNull(),
});

export const insertSenderSchema = createInsertSchema(sendersTable).omit({ id: true });
export type InsertSender = z.infer<typeof insertSenderSchema>;
export type Sender = typeof sendersTable.$inferSelect;
