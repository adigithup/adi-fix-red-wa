import { pgTable, serial, text, bigint } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const historyTable = pgTable("history", {
  id: serial("id").primaryKey(),
  phone: text("phone").notNull(),
  status: text("status").notNull().default("success"), // "success" | "fail"
  appealId: text("appeal_id"),
  sender: text("sender"),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
});

export const insertHistorySchema = createInsertSchema(historyTable).omit({ id: true });
export type InsertHistory = z.infer<typeof insertHistorySchema>;
export type History = typeof historyTable.$inferSelect;
